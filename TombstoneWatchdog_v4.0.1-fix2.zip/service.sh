#!/system/bin/sh
# TombstoneWatchdog - v4.0.0 service.sh
# 开机启动 + 状态管理
#
# 用法：
#   service.sh            开机启动（默认）
#   service.sh --status   查看状态
#   service.sh --stop     停止守护
#   service.sh --restart  重启守护
#   service.sh --help     显示帮助

MODDIR=${0%/*}
cd "$MODDIR" || exit 1

BINARY="$MODDIR/bin/tombstone_watchdog"
APPTYPE_DEX="$MODDIR/bin/apptype.dex"
SYSAPPS_CACHE="$MODDIR/.system_apps_cache"
BOOT_HIST="$MODDIR/.boot_history"
SAFE_FLAG="$MODDIR/.safe_mode"
CRASH_FLAG="$MODDIR/.last_crash"
SNAPSHOT="$MODDIR/.crash_snapshot"
LOG_MAIN="$MODDIR/watchdog.log"
LOG_DEBUG="$MODDIR/watchdog_debug.log"
LOG_INTERNAL="$MODDIR/watchdog_internal.log"
STATE_DIR="$MODDIR/.state"
NOW=$(date +%s)

# ============================================================
# 子命令
# ============================================================
show_status() {
    echo "===== TombstoneWatchdog 状态 ====="
    PID=$(pidof tombstone_watchdog 2>/dev/null)
    if [ -n "$PID" ]; then
        echo "进程: 运行中 PID=$PID"
    else
        echo "进程: 未运行"
    fi
    echo ""
    echo "冻结中:"
    if [ -d "$STATE_DIR" ]; then
        CNT=0
        for d in "$STATE_DIR"/*; do
            [ -d "$d" ] || continue
            USER=$(basename "$d")
            for f in "$d"/*.frozen; do
                [ -f "$f" ] || continue
                PKG=$(basename "$f" .frozen)
                if [ "$USER" = "0" ]; then
                    echo "  $PKG"
                else
                    echo "  $USER:$PKG"
                fi
                CNT=$((CNT + 1))
            done
        done
        [ "$CNT" = "0" ] && echo "  (无)"
    else
        echo "  (无)"
    fi
    echo ""
    echo "日志:"
    for f in "$LOG_MAIN" "$LOG_DEBUG" "$LOG_INTERNAL"; do
        [ -f "$f" ] && echo "  $(wc -c < "$f") bytes  $(basename "$f")"
    done
    echo ""
    if [ -f "$SAFE_FLAG" ]; then
        echo "安全模式: 已启用"
    else
        echo "安全模式: 未启用"
    fi
}

do_stop() {
    echo "停止守护进程..."
    pkill -f tombstone_watchdog 2>/dev/null
    sleep 2
    PID=$(pidof tombstone_watchdog 2>/dev/null)
    if [ -n "$PID" ]; then
        kill -9 $PID 2>/dev/null
        sleep 1
    fi
    CNT=0
    for f in /sys/fs/cgroup/uid_*/cgroup.freeze; do
        [ -f "$f" ] || continue
        [ "$(cat "$f" 2>/dev/null)" = "1" ] && { echo 0 > "$f" 2>/dev/null; CNT=$((CNT + 1)); }
    done
    echo "已停，解冻 $CNT 个 UID"
    rm -f "$MODDIR/.watchdog.lock"
}

do_restart() {
    do_stop
    sleep 1
    echo "启动守护进程..."
    if [ -x "$MODDIR/bin/start_watchdog.sh" ]; then
        rm -f "$MODDIR/.watchdog.lock"
        if command -v setsid >/dev/null 2>&1; then
            setsid "$MODDIR/bin/start_watchdog.sh" >/dev/null 2>&1 &
        else
            nohup "$MODDIR/bin/start_watchdog.sh" >/dev/null 2>&1 &
        fi
        sleep 5
        PID=$(pidof tombstone_watchdog 2>/dev/null)
        if [ -n "$PID" ]; then
            echo "已启动 PID=$PID"
        else
            echo "启动失败"
        fi
    else
        echo "二进制不存在或不可执行: $BINARY"
    fi
}

case "$1" in
    --status)  show_status; exit 0 ;;
    --stop)    do_stop; exit 0 ;;
    --restart) do_restart; exit 0 ;;
    --help|-h)
        echo "用法: service.sh [--status|--stop|--restart]"
        echo "  无参数      开机启动（默认）"
        echo "  --status    查看状态"
        echo "  --stop      停止守护"
        echo "  --restart   重启守护"
        echo "  --help      显示帮助"
        exit 0
        ;;
esac

# ============================================================
# 开机启动主流程
# ============================================================

# ========== 权限规整 ==========
chmod 644 "$MODDIR/config.conf" 2>/dev/null
chmod 644 "$SYSAPPS_CACHE" 2>/dev/null
chmod 755 "$MODDIR/bin/"*.dex 2>/dev/null
chmod 755 "$BINARY" "$MODDIR/bin/start_watchdog.sh" 2>/dev/null

# ========== 异常重启检测 ==========
BOOT_REASON=$(getprop ro.boot.bootreason)
case "$BOOT_REASON" in
    *userrequested*|*recovery*|*bootloader*|*shutdown*|*reboot*|"")
        rm -f "$CRASH_FLAG"
        ;;
    *)
        echo "boot_reason=$BOOT_REASON at $(date '+%Y-%m-%d %H:%M:%S')" > "$CRASH_FLAG"
        ;;
esac

if [ -f "$CRASH_FLAG" ]; then
    DIAG="/sdcard/TombstoneWatchdog_crash_$(date +%Y%m%d_%H%M%S).txt"
    {
        echo "===== 守护墓碑 异常重启诊断 ====="
        echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "开机原因: $BOOT_REASON"
        echo ""
        echo "===== 崩溃前状态快照 ====="
        cat "$SNAPSHOT" 2>/dev/null || echo "(无快照)"
        echo ""
        echo "===== 上次日志尾部（最后 300 行）====="
        tail -n 300 "$LOG_MAIN" 2>/dev/null
        echo ""
        echo "===== 系统 ANR trace ====="
        if [ -d /data/anr ]; then
            LATEST=$(ls -t /data/anr 2>/dev/null | head -1)
            if [ -n "$LATEST" ]; then
                echo "文件: /data/anr/$LATEST"
                tail -n 500 "/data/anr/$LATEST" 2>/dev/null
            else
                echo "(无 ANR 文件)"
            fi
        fi
        echo ""
        echo "===== 设备信息 ====="
        echo "品牌: $(getprop ro.product.brand)"
        echo "型号: $(getprop ro.product.model)"
        echo "系统: $(getprop ro.build.version.release)"
        echo "SDK: $(getprop ro.build.version.sdk)"
    } > "$DIAG" 2>&1

    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 生成崩溃诊断: $DIAG" >> "$LOG_MAIN"
    rm -f "$CRASH_FLAG"
fi

# ========== 旧格式 .state 清理（v3.9.4 升级兼容）==========
if [ -d "$STATE_DIR" ]; then
    OLD=$(find "$STATE_DIR" -maxdepth 1 -name 'frozen_*' 2>/dev/null | head -1)
    if [ -n "$OLD" ]; then
        rm -rf "$STATE_DIR"
        mkdir -p "$STATE_DIR"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 清理旧 .state 格式" >> "$LOG_MAIN"
    fi
fi

# ========== 后台刷新系统应用缓存 ==========
(
    sleep 20
    if [ -f "$APPTYPE_DEX" ]; then
        CLASSPATH="$APPTYPE_DEX" timeout 15 app_process /system/bin com.tombstone.apptype.Main 2>/dev/null | sort -u > "$SYSAPPS_CACHE.tmp"
        if [ -s "$SYSAPPS_CACHE.tmp" ]; then
            mv -f "$SYSAPPS_CACHE.tmp" "$SYSAPPS_CACHE"
            chmod 644 "$SYSAPPS_CACHE"
        else
            rm -f "$SYSAPPS_CACHE.tmp"
        fi
    fi
) &

# ========== 安全模式检测 ==========
touch "$BOOT_HIST" 2>/dev/null

if [ -f "$SAFE_FLAG" ]; then
    T0=$(cat "$SAFE_FLAG" 2>/dev/null)
    if [ -n "$T0" ]; then
        ELAPSED=$((NOW - T0))
        if [ "$ELAPSED" -ge 900 ]; then
            NEW_BOOTS=$(awk -v t="$T0" '$1 > t' "$BOOT_HIST" 2>/dev/null | wc -l)
            if [ "$NEW_BOOTS" -le 0 ]; then
                rm -f "$SAFE_FLAG"
            fi
        fi
    fi
fi

echo "$NOW" >> "$BOOT_HIST"
CUTOFF=$((NOW - 86400))
awk -v c="$CUTOFF" '$1 >= c' "$BOOT_HIST" > "$BOOT_HIST.tmp" && mv "$BOOT_HIST.tmp" "$BOOT_HIST"

if [ ! -f "$SAFE_FLAG" ]; then
    C3=$(awk -v now="$NOW" 'now - $1 < 300' "$BOOT_HIST" | wc -l)
    C5=$(awk -v now="$NOW" 'now - $1 < 900' "$BOOT_HIST" | wc -l)
    if [ "$C3" -ge 3 ] || [ "$C5" -ge 5 ]; then
        echo "$NOW" > "$SAFE_FLAG"
        exit 0
    fi
fi

if [ -f "$SAFE_FLAG" ]; then
    exit 0
fi

# ========== 启动守护 ==========
if [ -x "$MODDIR/bin/start_watchdog.sh" ]; then
    rm -f "$MODDIR/.watchdog.lock"
    if command -v setsid >/dev/null 2>&1; then
        setsid "$MODDIR/bin/start_watchdog.sh" >/dev/null 2>&1 &
    else
        nohup "$MODDIR/bin/start_watchdog.sh" >/dev/null 2>&1 &
    fi
fi
