#!/system/bin/sh
pkill -f watchdog.sh 2>/dev/null
rm -rf /data/adb/modules/TombstoneWatchdog/.state
rm -f /data/adb/modules/TombstoneWatchdog/.watchdog.lock
