'use strict';
/* ============================================================
   守护墓碑 v4.0.1 · WebUI（毛玻璃版）
   ------------------------------------------------------------
   双模式：
   - 真机模式：检测到 KernelSU bridge（ksu.exec）时自动启用，
     读取/写入 /data/adb/modules/TombstoneWatchdog 下真实数据。
   - 演示模式：无 bridge（浏览器直接打开）时使用模拟数据，
     完整可交互预览，便于开发调试。
   真机图标：ksu://icon/<包名>；演示图标：品牌色首字。
   ============================================================ */

/* ---------- 工具 ---------- */
function $(id){return document.getElementById(id)}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let toastTimer=null;
function toast(msg){
  const t=$('toast');if(!t)return;
  t.textContent=msg;t.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2600);
}
function animateNum(el,target,dur){
  if(!el)return;const start=parseInt(el.textContent,10)||0;const end=parseInt(target,10)||0;
  if(start===end){el.textContent=end;return}
  const t0=performance.now(),d=dur||500;
  (function tick(now){
    const p=Math.min((now-t0)/d,1),e=1-Math.pow(1-p,3);
    el.textContent=Math.round(start+(end-start)*e);
    if(p<1)requestAnimationFrame(tick);
  })(t0);
}
/* 启动加载层：数据就绪后淡出 */
function hideBoot(msg){
  const b=$('bootSplash');if(!b)return;
  if(msg&&$('bootSub'))$('bootSub').textContent=msg;
  setTimeout(()=>{
    b.classList.add('hide');
    setTimeout(()=>b.classList.add('gone'),450);
  },150);
}
/* 列表等图标加载完成后淡入展示 */
function revealWhenReady(container,timeout){
  if(!container)return;
  const imgs=container.querySelectorAll('img.app-ico.real');
  if(!imgs.length){container.classList.add('list-ready');return}
  container.classList.add('list-loading');
  let done=0,total=imgs.length,settled=false;
  const finish=()=>{
    if(settled)return;settled=true;
    container.classList.remove('list-loading');
    container.classList.add('list-ready');
  };
  imgs.forEach(img=>{
    if(img.complete&&img.naturalWidth>0){done++;if(done===total)finish();return}
    img.addEventListener('load',()=>{done++;if(done===total)finish()});
    img.addEventListener('error',()=>{done++;if(done===total)finish()});
  });
  setTimeout(finish,timeout||1800);
}

/* ============================================================
   KernelSU 桥接层
   ============================================================ */
function getKsu(){
  if(typeof ksu!=='undefined'&&ksu&&typeof ksu.exec==='function')return ksu;
  if(window.ksu&&typeof window.ksu.exec==='function')return window.ksu;
  if(window.$ksu&&typeof window.$ksu.exec==='function')return window.$ksu;
  return null;
}
async function exec(cmd){
  const k=getKsu();
  if(!k)return{errno:-1,stdout:'',stderr:'KSU_NOT_AVAILABLE'};
  try{
    const r=await k.exec(cmd);
    if(r&&typeof r==='object')return{errno:r.errno??0,stdout:r.stdout??'',stderr:r.stderr??''};
    return{errno:0,stdout:String(r),stderr:''};
  }catch(e){return{errno:-1,stdout:'',stderr:String(e)}}
}
const IS_KSU=!!getKsu();

/* ---------- 模块路径常量 ---------- */
const MODULE_ID='TombstoneWatchdog';
const MODDIR=`/data/adb/modules/${MODULE_ID}`;
const CONFIG_PATH=`${MODDIR}/config.conf`;
const LOG_PATH=`${MODDIR}/watchdog.log`;
const LOCK_PATH=`${MODDIR}/.watchdog.lock`;
const STATE_DIR=`${MODDIR}/.state`;
const STATS_DIR=`${MODDIR}/.stats`;
const DEX_PATH=`${MODDIR}/bin/pmlabel.dex`;
const BG_PATH=`${MODDIR}/webroot/custom_bg.img`;
const FALLBACK_ICON='data:image/svg+xml;utf8,'+encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="9" fill="#C7C7CC"/></svg>');

/* ---------- 配置读写 ---------- */
function parseConfig(text){
  const apps={},systemApps={},whitelist={},phoenix={};
  const settings={interval:1,minPullInterval:2,maxFailCount:3,batteryThreshold:20,oomAdj:-300,phoenixOomAdj:-600,statsEnabled:1,statsInterval:120,audioProtect:1,serviceProtect:1,overlayProtect:1};
  let mode='manual',section='';
  for(const raw of text.split('\n')){
    const line=raw.trim();
    if(!line||line.startsWith('#'))continue;
    if(line.startsWith('[')&&line.endsWith(']')){section=line.slice(1,-1);continue}
    const i=line.indexOf('=');
    if(i===-1)continue;
    const key=line.slice(0,i).trim(),val=line.slice(i+1).trim();
    if(section==='settings'){if(key==='mode')mode=val;else{const n=parseInt(val,10);if(!isNaN(n))settings[key]=n}}
    else if(section==='apps')apps[key]=val==='1';
    else if(section==='system_apps')systemApps[key]=val==='1';
    else if(section==='whitelist')whitelist[key]=val==='1';
    else if(section==='phoenix')phoenix[key]=val==='1';
  }
  return{mode,apps,systemApps,whitelist,phoenix,settings};
}
function serializeConfig(){
  const s=store.settings;
  const out=['# TombstoneWatchdog 配置文件','# 由 WebUI 自动管理','','[settings]'];
  out.push('mode='+store.mode,'interval='+s.interval,'minPullInterval='+s.minPullInterval,'maxFailCount='+s.maxFailCount,
    'batteryThreshold='+s.batteryThreshold,'oomAdj='+s.oomAdj,'phoenixOomAdj='+s.phoenixOomAdj,
    'statsEnabled='+s.statsEnabled,'statsInterval='+s.statsInterval,
    'audioProtect='+s.audioProtect,'serviceProtect='+s.serviceProtect,'overlayProtect='+s.overlayProtect);
  out.push('','[apps]');
  for(const[k,en]of Object.entries(store.third))out.push(k+'='+(en?1:0));
  out.push('','[system_apps]');
  for(const[k,en]of Object.entries(store.system))out.push(k+'='+(en?1:0));
  out.push('','[whitelist]');
  for(const[k,en]of Object.entries(store.white))out.push(k+'='+(en?1:0));
  out.push('','[phoenix]');
  for(const[k,en]of Object.entries(store.phoenix))out.push(k+'='+(en?1:0));
  out.push('');
  return out.join('\n');
}
async function readConfig(){
  const r=await exec(`base64 -w 0 ${CONFIG_PATH}`);
  if(r.errno!==0||!(r.stdout||'').trim())return null;
  try{return parseConfig(decodeURIComponent(escape(atob(r.stdout.trim()))))}catch(e){return null}
}
async function saveConfig(){
  const b64=btoa(unescape(encodeURIComponent(serializeConfig())));
  const r=await exec(`echo '${b64}' | base64 -d > ${CONFIG_PATH}.tmp && mv ${CONFIG_PATH}.tmp ${CONFIG_PATH}`);
  if(r.errno!==0)toast('保存失败');
}

/* ---------- key 工具 ---------- */
function makeKey(user,pkg){return user===0?pkg:`${user}:${pkg}`}
function parseKey(key){
  const c=key.indexOf(':');
  if(c===-1)return{user:0,pkg:key};
  const up=key.slice(0,c);
  if(/^\d+$/.test(up))return{user:parseInt(up,10),pkg:key.slice(c+1)};
  return{user:0,pkg:key};
}

/* ============================================================
   演示数据（无 KernelSU bridge 时使用）
   ============================================================ */
const GRADS={
  social:['#0A84FF','#4DA3FF'],video:['#FF3B30','#FF6B5E'],shop:['#FF9500','#FFB340'],
  music:['#BF5AF2','#AF52DE'],life:['#30D158','#5BE38A'],news:['#30B0C7','#5AC8FA'],
  sys:['#8E8E93','#636366']
};
const DEMO_APPS=[
  {n:'微信',p:'com.tencent.mm',c:'social',w:true},
  {n:'QQ',p:'com.tencent.mobileqq',c:'social',w:true},
  {n:'抖音',p:'com.ss.android.ugc.aweme',c:'video',f:true},
  {n:'快手',p:'com.smile.gifmaker',c:'video',f:true},
  {n:'哔哩哔哩',p:'tv.danmaku.bili',c:'video',f:true},
  {n:'小红书',p:'com.xingin.xhs',c:'social',f:true},
  {n:'微博',p:'com.sina.weibo',c:'news',f:true},
  {n:'知乎',p:'com.zhihu.android',c:'news',f:true},
  {n:'淘宝',p:'com.taobao.taobao',c:'shop',f:true},
  {n:'京东',p:'com.jingdong.app.mall',c:'shop',f:true},
  {n:'拼多多',p:'com.xunmeng.pinduoduo',c:'shop',f:true},
  {n:'美团',p:'com.sankuai.meituan',c:'life',f:true},
  {n:'饿了么',p:'me.ele',c:'life'},
  {n:'高德地图',p:'com.autonavi.minimap',c:'life',w:true},
  {n:'网易云音乐',p:'com.netease.cloudmusic',c:'music',x:true},
  {n:'QQ音乐',p:'com.tencent.qqmusic',c:'music',x:true},
  {n:'支付宝',p:'com.eg.android.AlipayGphone',c:'life',x:true},
  {n:'闲鱼',p:'com.taobao.idlefish',c:'shop',f:true},
];
const DEMO_SYS=[
  {n:'系统界面',p:'com.android.systemui',c:'sys',w:true},
  {n:'设置',p:'com.android.settings',c:'sys'},
  {n:'相机',p:'com.android.camera',c:'sys'},
  {n:'相册',p:'com.android.gallery3d',c:'sys',f:true},
  {n:'浏览器',p:'com.android.browser',c:'sys',f:true},
  {n:'输入法',p:'com.android.inputmethod',c:'sys',w:true},
];

/* ---------- 统一状态 ---------- */
const store={
  mode:'manual',
  third:{},system:{},white:{},phoenix:{},
  settings:{interval:1,minPullInterval:2,maxFailCount:3,batteryThreshold:20,oomAdj:-300,phoenixOomAdj:-600,statsEnabled:1,statsInterval:120,audioProtect:1,serviceProtect:1,overlayProtect:1},
  curTab:'home',logMode:'simple',query:'',pickerBack:'white',chartRange:'1h',
  apps:[],frozenKeys:[],statsData:[],logItems:[],logRaw:'',
};
/* 演示模式初始填充 */
if(!IS_KSU){
  for(const a of DEMO_APPS){
    store.apps.push({key:a.p,pkg:a.p,name:a.n,userId:0,cat:a.c,isSystem:false});
    if(!a.w&&!a.x)store.third[a.p]=true;
    if(a.w)store.white[a.p]=true;
    if(a.x)store.phoenix[a.p]=true;
  }
  for(const a of DEMO_SYS){
    store.apps.push({key:a.p,pkg:a.p,name:a.n,userId:0,cat:a.c,isSystem:true});
    if(!a.w)store.system[a.p]=true;
    if(a.w)store.white[a.p]=true;
  }
  store.frozenKeys=[...DEMO_APPS,...DEMO_SYS].filter(a=>a.f).map(a=>a.p);
}
/* 冻结判断：统一走 frozenKeys（真机=守护进程实际冻结状态，演示=静态模拟） */
function hasFrozen(key){return store.frozenKeys.includes(key)}
const frozenCount=()=>store.frozenKeys.length;
const protectedCount=()=>{
  const set=new Set([...Object.keys(store.third),...Object.keys(store.system),...Object.keys(store.phoenix)].filter(k=>store.third[k]||store.system[k]||store.phoenix[k]));
  return set.size;
};
const phoenixCount=()=>Object.values(store.phoenix).filter(Boolean).length;

/* ============================================================
   真机数据加载（仅 IS_KSU 时调用）
   ============================================================ */
function pkgToReadableName(pkg){
  const m=String(pkg).match(/^(?:com|org|io|net|cn|me|co|app|bin)\.(.+)$/i);
  return m?m[1]:pkg;
}
const labelCache={};
function appNameOf(key){
  if(!key)return '';
  const k=parseKey(key),full=makeKey(k.user,k.pkg);
  if(labelCache[full])return labelCache[full];
  const a=store.apps.find(x=>x.key===full);
  if(a)return a.name;
  return k.pkg;
}
async function getUsers(){
  const r=await exec('pm list users 2>/dev/null | base64 -w 0');
  const users=[];
  let out='';
  if(r.errno===0&&(r.stdout||'').trim()){
    try{out=decodeURIComponent(escape(atob((r.stdout||'').trim())))}catch(e){out=r.stdout||''}
  }
  const re=/UserInfo\{(\d+):([^:}]+)/g;
  let m;
  while((m=re.exec(out))!==null){
    const id=parseInt(m[1],10);
    if(!users.find(u=>u.id===id))users.push({id,name:m[2]});
  }
  if(!users.find(u=>u.id===0))users.unshift({id:0,name:'Owner'});
  return users;
}
async function loadPackages(){
  try{
    const users=await getUsers();
    const third=[],sys=[],seen=new Set();
    for(const u of users){
      const r3=await exec(`cmd package list packages --user ${u.id} -3 | paste -sd ' '`);
      if(r3.errno===0){
        for(const item of(r3.stdout||'').trim().split(/\s+/)){
          const pkg=item.replace('package:','').trim();
          if(!pkg)continue;
          const key=makeKey(u.id,pkg);
          if(seen.has(key))continue;
          seen.add(key);
          third.push({key,packageName:pkg,userId:u.id,label:pkgToReadableName(pkg)});
        }
      }
      const rs=await exec(`cmd package list packages --user ${u.id} -s | paste -sd ' '`);
      if(rs.errno===0){
        for(const item of(rs.stdout||'').trim().split(/\s+/)){
          const pkg=item.replace('package:','').trim();
          if(!pkg)continue;
          const key=makeKey(u.id,pkg);
          if(seen.has(key))continue;
          seen.add(key);
          sys.push({key,packageName:pkg,userId:u.id,label:pkgToReadableName(pkg)});
        }
      }
    }
    /* 主用户第三方应用名：走模块自带 pmlabel.dex 解析真实标签 */
    const mainPkgs=third.filter(p=>p.userId===0).map(p=>p.packageName);
    if(mainPkgs.length>0){
      const lr=await exec(`CLASSPATH=${DEX_PATH} app_process /system/bin com.tombstone.pmlabel.Main ${mainPkgs.join(' ')}`);
      if(lr.errno===0&&(lr.stdout||'').length>0){
        for(const entry of lr.stdout.split('\u0002')){
          if(!entry)continue;
          const idx=entry.indexOf('\u0001');
          if(idx===-1)continue;
          const pkg=entry.slice(0,idx),label=entry.slice(idx+1);
          const t=third.find(p=>p.packageName===pkg&&p.userId===0);
          if(t&&label)t.label=label;
        }
      }
    }
    const nameMap={};
    for(const p of third){
      if(p.userId===0&&p.label&&p.label!==p.packageName)nameMap[p.packageName]=p.label;
      labelCache[makeKey(p.userId,p.packageName)]=p.label||p.packageName;
    }
    for(const p of third){
      if(p.userId!==0&&nameMap[p.packageName]){p.label=nameMap[p.packageName];labelCache[makeKey(p.userId,p.packageName)]=p.label}
    }
    for(const p of sys)labelCache[makeKey(p.userId,p.packageName)]=p.label||p.packageName;
    store.apps=[
      ...third.map(p=>({key:p.key,pkg:p.packageName,name:p.label||pkgToReadableName(p.packageName),userId:p.userId,cat:null,isSystem:false})),
      ...sys.map(p=>({key:p.key,pkg:p.packageName,name:p.label||pkgToReadableName(p.packageName),userId:p.userId,cat:null,isSystem:true}))
    ];
  }catch(e){console.warn('loadPackages 失败:',e)}
}
async function getFrozenKeys(){
  const r=await exec(`cd "${STATE_DIR}" 2>/dev/null && find . -mindepth 2 -maxdepth 2 -name '*.frozen' 2>/dev/null | paste -sd ' '`);
  const keys=[];
  const out=(r.stdout||'').trim();
  if(!out)return keys;
  out.split(/\s+/).forEach(p=>{
    if(!p.startsWith('./'))return;
    const parts=p.substring(2).split('/');
    if(parts.length!==2)return;
    const user=parts[0];
    let pkg=parts[1];
    if(!pkg.endsWith('.frozen'))return;
    pkg=pkg.substring(0,pkg.length-7);
    if(!pkg||!/^\d+$/.test(user))return;
    keys.push(user==='0'?pkg:`${user}:${pkg}`);
  });
  return keys;
}
async function checkStatus(){
  const title=$('heroTitle'),sub=$('heroSub'),card=$('heroCard');
  if(!title||!sub||!card)return;
  const k=getKsu();
  if(!k){card.className='hero unknown';title.textContent='KSU 桥接未注入';sub.textContent='请使用 KernelSU 打开';return}
  const lock=await exec(`cat ${LOCK_PATH}`);
  let pid=(lock.stdout||'').trim();
  let alive=false;
  if(pid&&/^\d+$/.test(pid)){
    const chk=await exec(`[ -d /proc/${pid} ] && echo yes || echo no`);
    alive=(chk.stdout||'').trim()==='yes';
  }
  store.frozenKeys=await getFrozenKeys();
  if(alive){
    card.className='hero ok';
    title.textContent='守护进程运行中';
    sub.textContent=`PID ${pid} · 系统运行正常`;
  }else{
    card.className='hero '+(pid?'warn':'bad');
    title.textContent='守护进程未运行';
    sub.textContent=pid?`锁文件 PID=${pid} 已不存在`:'未找到锁文件';
  }
  renderStats();
  renderRecent();
}
async function loadStats(){
  const d=new Date();
  const today=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  const path=`${STATS_DIR}/${today}.log`;
  const r=await exec(`base64 -w 0 ${path} 2>/dev/null`);
  store.statsData=[];
  if(r.errno===0&&(r.stdout||'').trim()){
    let text='';
    try{text=decodeURIComponent(escape(atob(r.stdout.trim())))}catch(e){text=''}
    const lines=text.split('\n').filter(Boolean);
    for(let i=1;i<lines.length;i++){
      const p=lines[i].trim().split(/\s+/);
      if(p.length!==3)continue;
      const cpu=parseFloat(p[1]),mem=parseFloat(p[2]);
      if(isNaN(cpu)||isNaN(mem))continue;
      store.statsData.push({time:p[0],cpu,mem});
    }
  }
  renderChart();
}
async function loadLogs(){
  const r=await exec(`tail -n 500 ${LOG_PATH} 2>/dev/null | base64 -w 0 2>/dev/null`);
  let text='';
  if(r.errno===0&&(r.stdout||'').trim()){
    try{text=decodeURIComponent(escape(atob((r.stdout||'').trim())))}catch(e){text=''}
  }
  store.logRaw=text;
  /* 解析为统一日志项 */
  const KNOWN=['FREEZE','UNFREEZE','FG-UNFREEZE','PHOENIX-FREEZE','SKIP-FREEZE','GONE','ORPHAN-UNFREEZE','FAIL-FREEZE','PID-CHANGED','FG-SET','MODE','LAUNCH-UNFREEZE','GONE-UNFREEZE','YOUNG-UNFREEZE'];
  const items=[];
  const todayStr=new Date().toDateString();
  for(const line of text.split('\n')){
    const m=line.match(/^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]\s+(.+)$/);
    if(!m)continue;
    let rest=m[2];
    const lvl=rest.match(/^\[([UDI])\]\s+(.+)$/);
    if(lvl)rest=lvl[2];
    const parts=rest.split(/\s+/);
    const event=parts[0]||'OTHER';
    if(KNOWN.indexOf(event)<0)continue;
    const key=parts[1]||'',detail=parts.slice(2).join(' ');
    const name=appNameOf(key)||key;
    let type='other',d2='';
    if(event==='FREEZE'||event==='PHOENIX-FREEZE'){type='freeze';d2=event==='PHOENIX-FREEZE'?'不死鸟保护':''}
    else if(event==='UNFREEZE'||event==='FG-UNFREEZE'){type='unfreeze'}
    else if(event==='SKIP-FREEZE'){type='skip';d2=detail.indexOf('音频')>=0?'正在播放音频':detail.indexOf('前台服务')>=0?'持有前台服务':detail.indexOf('悬浮窗')>=0?'显示悬浮窗':detail}
    else if(event==='GONE'){type='gone'}
    else if(event==='ORPHAN-UNFREEZE'){type='unfreeze';d2='不在名单中'}
    else if(event==='FAIL-FREEZE'){type='fail'}
    else continue;
    const dt=new Date(m[1].replace(' ','T'));
    items.push({type,name,pkg:parseKey(key).pkg,detail:d2,time:dt,day:dt.toDateString()===todayStr?'today':'yest'});
  }
  items.sort((a,b)=>a.time-b.time);
  store.logItems=items;
  renderLogs();
}

/* ============================================================
   真机：背景 / 导出 / 安全模式
   ============================================================ */
async function loadCustomBg(){
  const el=$('bgStatus'),clearRow=$('bgClearRow');
  try{
    const r=await exec(`base64 -w 0 ${BG_PATH} 2>/dev/null`);
    if(r.errno===0&&(r.stdout||'').trim()){
      applyBg('data:image/jpeg;base64,'+r.stdout.trim());
      if(el)el.textContent='已设置';
      if(clearRow)clearRow.style.display='';
    }else{
      if(el)el.textContent='未设置';
      if(clearRow)clearRow.style.display='none';
    }
  }catch(e){
    if(el)el.textContent='未设置';
  }
}
async function saveBgToFile(dataUrl){
  const b64=dataUrl.split(',')[1];
  if(!b64)throw new Error('图片数据为空');
  const tmpPath='/data/local/tmp/custom_bg.b64';
  const chunkSize=60*1024;
  await exec(`rm -f ${tmpPath} ${BG_PATH}`);
  for(let i=0;i<b64.length;i+=chunkSize){
    const chunk=b64.slice(i,i+chunkSize);
    const op=i===0?'>':'>>';
    const r=await exec(`printf '%s' '${chunk}' ${op} ${tmpPath}`);
    if(r.errno!==0)throw new Error('写入中断');
  }
  const r2=await exec(`base64 -d ${tmpPath} > ${BG_PATH} && rm -f ${tmpPath} && chmod 644 ${BG_PATH}`);
  if(r2.errno!==0)throw new Error('保存失败');
}
async function clearBgReal(){
  try{
    await exec(`rm -f ${BG_PATH}`);
    applyBg(null);
    if($('bgStatus'))$('bgStatus').textContent='未设置';
    if($('bgClearRow'))$('bgClearRow').style.display='none';
    toast('背景已清除');
  }catch(e){toast('清除失败')}
}
async function exportDiag(){
  if(!IS_KSU){toast('演示模式：报告将生成到 /sdcard/TombstoneWatchdog_diag_<时间戳>.txt');return}
  const now=new Date();
  const pad=n=>String(n).padStart(2,'0');
  const stamp=now.getFullYear()+pad(now.getMonth()+1)+pad(now.getDate())+'_'+pad(now.getHours())+pad(now.getMinutes())+pad(now.getSeconds());
  const target='/sdcard/TombstoneWatchdog_diag_'+stamp+'.txt';
  const cmd='{ '+
    'echo "===== 诊断报告 ====="; date; '+
    'sh /data/adb/modules/TombstoneWatchdog/bin/diag.sh; echo ""; '+
    'echo "===== 设备信息 ====="; '+
    'getprop ro.product.brand; getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.sdk; echo ""; '+
    'echo "===== 完整日志 ====="; cat /data/adb/modules/TombstoneWatchdog/watchdog.log; '+
    '} > "'+target+'"';
  toast('导出中…');
  const r=await exec(cmd);
  if(r.errno!==0){toast('导出失败，请检查权限');return}
  toast('已导出到 '+target);
}
async function checkSafeMode(){
  const banner=$('safeBanner');
  if(!banner)return;
  const r=await exec(`cat ${MODDIR}/.safe_mode 2>/dev/null`);
  const content=(r.stdout||'').trim();
  if(!content){banner.classList.remove('show');document.body.classList.remove('has-safe');return}
  const t0=parseInt(content,10)*1000;
  const remain=Math.max(0,900000-(Date.now()-t0));
  banner.classList.add('show');document.body.classList.add('has-safe');
  const sub=$('safeSub');
  if(sub)sub.textContent=remain>0?('检测到短时间内多次重启 · '+Math.ceil(remain/60000)+' 分钟后可退出'):'冷却期已过 · 请点击右侧退出按钮';
}
async function exitSafeMode(){
  const ok=await confirmBox('退出安全模式',['退出后，守护进程将在下次开机时启动。','为避免再次崩溃，模式将切换到「手动选择」。','如需恢复原模式，请重启后在 WebUI 中手动切换。'],'确认退出','取消');
  if(!ok)return;
  await exec(`rm -f ${MODDIR}/.safe_mode ${MODDIR}/.boot_history`);
  store.mode='manual';
  await saveConfig();
  toast('已退出，请重启手机');
  const b=$('safeBanner');
  if(b){b.classList.remove('show');document.body.classList.remove('has-safe')}
}

/* ---------- 系统冻结器冲突检测 ---------- */
/* Android 15/16 的 CachedAppOptimizer 与本模块冻结机制冲突：
   被冻结应用会被反复解冻再冻结，反而更耗电。
   在首页初始化时检测一次，enabled / device_default 时引导用户关闭。 */
async function checkFreezerConflict(){
  if(!IS_KSU)return;
  const r=await exec('settings get global cached_apps_freezer');
  const st=(r.stdout||'').trim().toLowerCase();
  if(st!=='enabled'&&st!=='device_default')return; /* disabled 或读取失败：不打扰 */
  showFreezerModal();
}
function showFreezerModal(){
  const m=$('freezerModal');if(!m)return;
  $('freezerTitle').textContent='检测到系统冻结器冲突';
  $('freezerMsg').textContent='系统自带的冻结器与本模块存在冲突，可能导致应用被反复唤醒、反而更耗电。建议关闭。关闭后需要重启手机才能完全生效。';
  const later=$('freezerLater'),close=$('freezerClose');
  later.textContent='稍后';
  close.textContent='立即关闭';
  close.classList.add('warn');
  later.onclick=()=>m.classList.remove('show'); /* 不记忆，下次进首页仍提示 */
  close.onclick=async()=>{
    close.disabled=true;close.textContent='关闭中…';
    const r=await exec('settings put global cached_apps_freezer disabled');
    close.disabled=false;
    if(r.errno!==0){close.textContent='立即关闭';toast('操作失败，请检查 Root 权限');return}
    showFreezerReboot();
  };
  m.classList.add('show');
}
function showFreezerReboot(){
  const m=$('freezerModal');if(!m)return;
  $('freezerTitle').textContent='需要重启';
  $('freezerMsg').textContent='系统冻结器已成功关闭，但需要重启手机才能完全生效。';
  const later=$('freezerLater'),close=$('freezerClose');
  later.textContent='稍后手动重启';
  close.textContent='立即重启';
  close.classList.add('warn');
  later.onclick=()=>m.classList.remove('show');
  close.onclick=()=>{exec('svc power reboot');toast('正在重启…')};
}

/* ============================================================
   图标
   ============================================================ */
function appIconFor(pkg,size){
  const useReal=IS_KSU;
  if(useReal)return '<img class="app-ico real'+(size?' sm'+size:'')+'" src="ksu://icon/'+pkg+'" onerror="this.onerror=null;this.src=\''+FALLBACK_ICON+'\'" alt="">';
  const a=store.apps.find(x=>x.pkg===pkg);
  return appIconHTML(a||{name:pkg,cat:'sys'},size);
}
function appIconHTML(a,size){
  const g=GRADS[a.cat]||GRADS.sys;
  const frozen=hasFrozen(a.key||a.pkg);
  return '<div class="app-ico'+(size?' sm'+size:'')+'" style="background:linear-gradient(135deg,'+g[0]+','+g[1]+')">'+esc(a.name.charAt(0))+
    (frozen?'<span class="frozen-mark"><svg viewBox="0 0 24 24"><path d="M12 2c-.3 0-.6.1-.8.4C11 2.7 7 7.6 7 12a5 5 0 0 0 10 0c0-4.4-4-9.3-4.2-9.6-.2-.3-.5-.4-.8-.4z"/></svg></span>':'')+'</div>';
}
function appDisplayName(a){
  return a.userId!==0?a.name+` (分身${a.userId})`:a.name;
}

/* ============================================================
   图表
   ============================================================ */
let _demoStats=null;
function demoStats(){
  if(_demoStats)return _demoStats;
  const out=[],t=new Date();t.setMinutes(t.getMinutes()-24*60);
  let cpu=34,mem=420;
  for(let i=0;i<288;i++){
    cpu=Math.max(8,Math.min(78,cpu+(Math.sin(i*1.3)*9)+(Math.random()*14-7)));
    mem=Math.max(360,Math.min(560,mem+(Math.sin(i*.7+2)*12)+(Math.random()*12-6)));
    out.push({t:new Date(t.getTime()+i*5*60000),cpu:+cpu.toFixed(1),mem:+mem.toFixed(1)});
  }
  _demoStats=out;return out;
}
function chartWindow(){
  const range=store.chartRange||'1h';
  const rangeMin={'1h':60,'6h':360,'24h':1440}[range]||60;
  const offset=Math.max(0,store.chartOffset||0);
  const end=new Date(Date.now()-offset*rangeMin*60000);
  const start=new Date(end.getTime()-rangeMin*60000);
  const raw=store.statsData.length?store.statsData:demoStats();
  const norm=raw.map(d=>{
    let t=d.time!==undefined?d.time:d.t;
    if(typeof t==='string'){
      const p=t.split(':');
      const dt=new Date();dt.setHours(+p[0],+p[1],+p[2]||0,0);
      t=dt;
    }
    return{t,cpu:d.cpu,mem:d.mem};
  }).sort((a,b)=>a.t-b.t);
  const data=norm.filter(d=>d.t>=start&&d.t<end);
  return{data,start,end,rangeMin,src:norm};
}
function chartData(){return chartWindow().data}
function shiftChart(delta){
  const {rangeMin,src}=chartWindow();
  let off=Math.max(0,(store.chartOffset||0)+delta);
  if(src.length){
    const first=src[0].t.getTime(),now=Date.now();
    const maxOff=Math.max(0,Math.floor((now-first)/60000/rangeMin));
    off=Math.min(off,maxOff);
  }
  if(off===(store.chartOffset||0))return;
  store.chartOffset=off;
  renderChart(delta>0?1:-1);
}
function updateChartWindowLabel(start,end,rangeMin,src){
  const lbl=$('cwLabel'),prev=$('cwPrev'),next=$('cwNext');
  if(!lbl)return;
  const fmt=d=>String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
  lbl.textContent=fmt(start)+' – '+fmt(end);
  const offset=store.chartOffset||0;
  if(next){next.disabled=offset<=0;next.style.opacity=next.disabled?'.3':''}
  let maxOff=Infinity;
  if(src.length){
    const first=src[0].t.getTime(),now=Date.now();
    maxOff=Math.max(0,Math.floor((now-first)/60000/rangeMin));
  }
  if(prev){prev.disabled=offset>=maxOff;prev.style.opacity=prev.disabled?'.3':''}
}
/* 图表手势状态（模块级，renderChart 只更新引用，监听器只绑一次） */
let _chartSvg=null,_chartTip=null,_chartM=null,_chartBound=false;
let _drag=null;
function bindChartGestures(){
  if(_chartBound)return;_chartBound=true;
  const wrap=$('chartWrap');if(!wrap)return;
  function showAt(cx){
    const svg=_chartSvg,m=_chartM,tip=_chartTip;
    if(!svg||!m)return;
    const r=svg.getBoundingClientRect();
    const ratio=Math.max(0,Math.min(1,(cx-r.left)/r.width));
    const idx=Math.round(ratio*(m.DATA.length-1));
    const d=m.DATA[idx],px=m.X(idx);
    const dots=svg.querySelectorAll('.chart-dot'),cursor=svg.querySelector('.chart-cursor');
    cursor.setAttribute('x1',px);cursor.setAttribute('x2',px);cursor.style.opacity=1;
    dots[0].setAttribute('cx',px);dots[0].setAttribute('cy',m.Y(d.cpu,m.maxC));dots[0].style.opacity=1;
    dots[1].setAttribute('cx',px);dots[1].setAttribute('cy',m.Y(d.mem,m.maxM));dots[1].style.opacity=1;
    const hm=d.t.getHours(),mm=String(d.t.getMinutes()).padStart(2,'0');
    tip.innerHTML='<b>'+hm+':'+mm+'</b>　CPU '+d.cpu+'%<br><b>内存</b> '+d.mem+'MB';
    tip.classList.add('show');
    const tw=tip.offsetWidth||110,half=tw/2;
    const lx=(px/m.W)*r.width;
    tip.style.left=Math.max(half,Math.min(r.width-half,lx))+'px';
  }
  function hide(){
    const svg=_chartSvg,tip=_chartTip;
    if(!svg||!tip)return;
    svg.querySelectorAll('.chart-dot').forEach(d=>d.style.opacity=0);
    svg.querySelector('.chart-cursor').style.opacity=0;
    tip.classList.remove('show');
  }
  function dragStart(cx){
    _drag={x:cx};
    if(wrap.contains(_chartSvg))showAt(cx);
  }
  /* 手指/鼠标按住滑动 → 光标与数值跟随，查看该时间点 */
  function dragMove(cx){
    if(!_drag||!wrap.contains(_chartSvg))return;
    showAt(cx);
  }
  function dragEnd(){
    if(!_drag)return;
    _drag=null;
    /* 松手后 tooltip 保持在最后查看的位置，方便读数 */
  }
  wrap.onmousemove=null;wrap.onmouseleave=null;
  wrap.addEventListener('mousemove',e=>{
    if(_drag){
      dragMove(e.clientX);
    }else showAt(e.clientX);
  });
  wrap.addEventListener('mouseleave',()=>{if(!_drag)hide()});
  wrap.addEventListener('mousedown',e=>{dragStart(e.clientX)});
  wrap.addEventListener('mouseup',()=>dragEnd());
  wrap.addEventListener('touchstart',e=>{if(e.touches[0])dragStart(e.touches[0].clientX)},{passive:true});
  wrap.addEventListener('touchmove',e=>{if(e.touches[0]&&_drag)dragMove(e.touches[0].clientX)},{passive:true});
  wrap.addEventListener('touchend',dragEnd,{passive:true});
  wrap.addEventListener('touchcancel',dragEnd,{passive:true});
}
function renderChart(dir){
  const wrap=$('chartWrap');if(!wrap)return;
  bindChartGestures();
  const {data:WINDOW,start,end,rangeMin,src}=chartWindow();
  const W=wrap.clientWidth||340,H=120,pad=6;
  if(!WINDOW.length){
    const old=wrap.querySelector('svg.chart-svg');if(old)old.remove();
    const tip=wrap.querySelector('.chart-tip');if(tip)tip.remove();
    if($('mCur'))$('mCur').textContent='--';
    if($('mPeak'))$('mPeak').textContent='--';
    if($('mAvg'))$('mAvg').textContent='--';
    if($('mCnt'))$('mCnt').textContent='0 点';
    updateChartWindowLabel(start,end,rangeMin,src);
    _chartSvg=null;_chartTip=null;_chartM=null;
    return;
  }
  const DATA=WINDOW;
  const maxC=Math.max(...DATA.map(d=>d.cpu))*1.15,maxM=Math.max(...DATA.map(d=>d.mem))*1.15;
  const X=i=>pad+(W-2*pad)*(DATA.length===1?.5:i/(DATA.length-1));
  const Y=(v,max)=>H-pad-(v/max)*(H-2*pad);
  const cpuPts=DATA.map((d,i)=>X(i)+','+Y(d.cpu,maxC)).join(' ');
  const memPts=DATA.map((d,i)=>X(i)+','+Y(d.mem,maxM)).join(' ');
  const areaPts='0,'+H+' '+DATA.map((d,i)=>X(i)+','+Y(d.mem,maxM)).join(' ')+' '+W+','+H;
  const oldSvg=wrap.querySelector('svg.chart-svg');
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.setAttribute('class','chart-svg');
  svg.setAttribute('viewBox','0 0 '+W+' '+H);svg.setAttribute('preserveAspectRatio','none');
  svg.innerHTML=
    '<g class="chart-grid">'+[0.25,0.5,0.75].map(f=>'<line x1="'+pad+'" y1="'+(H*f)+'" x2="'+(W-pad)+'" y2="'+(H*f)+'"/>').join('')+'</g>'+
    '<polygon class="chart-area" points="'+areaPts+'" fill="var(--green)"/>'+
    '<polyline class="chart-line" points="'+memPts+'" stroke="var(--green)"/>'+
    '<polyline class="chart-line" points="'+cpuPts+'" stroke="var(--accent)"/>'+
    '<line class="chart-cursor" y1="'+pad+'" y2="'+(H-pad)+'" x1="0" x2="0"/>'+
    '<circle class="chart-dot" r="4" fill="var(--accent)" stroke="#fff" stroke-width="1.5"/>'+
    '<circle class="chart-dot" r="4" fill="var(--green)" stroke="#fff" stroke-width="1.5"/>';
  let tip=wrap.querySelector('.chart-tip');
  if(!tip){tip=document.createElement('div');tip.className='chart-tip';wrap.appendChild(tip)}
  wrap.insertBefore(svg,tip);
  if(oldSvg&&dir){
    oldSvg.style.position='absolute';oldSvg.style.left='0';oldSvg.style.top='0';
    oldSvg.style.transition='transform .28s var(--ease-out),opacity .28s';
    oldSvg.style.transform='translateX('+(-dir*36)+'px)';oldSvg.style.opacity='0';
    svg.style.transform='translateX('+(dir*36)+'px)';svg.style.opacity='0';
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      svg.style.transition='transform .28s var(--ease-out),opacity .28s';
      svg.style.transform='';svg.style.opacity='1';
      setTimeout(()=>{if(oldSvg.parentNode)oldSvg.remove()},300);
    }));
  }else if(oldSvg){
    oldSvg.remove();
  }
  _chartSvg=svg;_chartTip=tip;_chartM={DATA,W,maxC,maxM,X,Y};
  const last=DATA[DATA.length-1];
  const sumC=DATA.reduce((s,d)=>s+d.cpu,0),sumM=DATA.reduce((s,d)=>s+d.mem,0);
  if($('mCur'))$('mCur').textContent=last.cpu+'% · '+last.mem+'MB';
  if($('mPeak'))$('mPeak').textContent=maxC.toFixed(0)+'% · '+maxM.toFixed(0)+'MB';
  if($('mAvg'))$('mAvg').textContent=(sumC/DATA.length).toFixed(1)+'% · '+(sumM/DATA.length).toFixed(1)+'MB';
  if($('mCnt'))$('mCnt').textContent=DATA.length+' 点';
  updateChartWindowLabel(start,end,rangeMin,src);
}

/* ============================================================
   首页
   ============================================================ */
const LOG_STYLE={
  freeze:['#0A84FF','冻'],
  unfreeze:['#30D158','解'],
  phoenix:['#BF5AF2','凤'],
  skip:['#FF9500','跳'],
  gone:['#8E8E93','逝'],
  fail:['#FF3B30','败'],
  other:['#8E8E93','?'],
};
const LOG_LABEL={
  freeze:'冻结',unfreeze:'解冻',phoenix:'不死鸟冻结',skip:'跳过冻结',gone:'进程消失',fail:'冻结失败',other:'其他'
};
function logCardHTML(item){
  const st=LOG_STYLE[item.type]||LOG_STYLE.other;
  const t=item.time;
  const hm=(t instanceof Date&&!isNaN(t))?(String(t.getHours()).padStart(2,'0')+':'+String(t.getMinutes()).padStart(2,'0')):String(item.time);
  const name=appNameOf(item.pkg)||item.name||item.pkg;
  return '<div class="log-item"><span class="log-ico-wrap">'+appIconFor(item.pkg,36)+
    '<span class="evt-badge" style="background:'+st[0]+'" title="'+LOG_LABEL[item.type]+'">'+st[1]+'</span></span>'+
    '<span class="log-body"><span class="log-title">'+esc(name)+'</span>'+(item.detail?'<span class="log-detail">'+esc(item.detail)+'</span>':'<span class="log-detail log-type-label">'+LOG_LABEL[item.type]+'</span>')+'</span>'+
    '<span class="log-time">'+hm+'</span></div>';
}
function renderRecent(){
  const wrap=$('recentList');if(!wrap)return;
  const items=store.logItems.slice(-5).reverse();
  wrap.innerHTML=items.length?items.map(logCardHTML).join(''):
    '<div class="empty" style="padding:24px 20px"><div class="t">暂无动态</div></div>';
  revealWhenReady(wrap);
}
function renderStats(){
  animateNum($('statFrozen'),frozenCount());
  animateNum($('statProtected'),protectedCount());
  animateNum($('statPhoenix'),phoenixCount());
  $('barFrozen').style.width=Math.min(100,frozenCount()*4)+'%';
  $('barProtected').style.width=Math.min(100,protectedCount()*3)+'%';
  $('barPhoenix').style.width=Math.min(100,phoenixCount()*12)+'%';
}
function renderHome(){
  renderStats();
  renderChart();
  renderRecent();
}

/* ============================================================
   导航 / Tab 指示器
   ============================================================ */
const TABS=['home','apps','logs','settings'];
function switchTab(name){
  store.curTab=name;
  document.querySelectorAll('.screen').forEach(s=>{if(s.closest('#subLayer'))return;s.classList.remove('active')});
  $('screen-'+name).classList.add('active');
  document.querySelectorAll('.tab-item').forEach(t=>t.classList.toggle('active',t.dataset.tab===name));
  closeSub();
  window.scrollTo(0,0);
  layoutInd();
}
const tabbar=$('tabbar'),tabInd=$('tabInd');
function layoutInd(){
  const a=tabbar.querySelector('.tab-item.active');
  if(!a)return;
  tabInd.style.left=a.offsetLeft+'px';
  tabInd.style.width=a.offsetWidth+'px';
}
let _indDrag=null;
tabbar.addEventListener('pointerdown',e=>{
  const a=tabbar.querySelector('.tab-item.active');
  _indDrag={sx:e.clientX,base:a?a.offsetLeft:6,moved:false,target:e.target.closest('.tab-item')};
  tabbar.classList.add('dragging','ind-pressed');
  try{tabbar.setPointerCapture(e.pointerId)}catch(_){}
});
tabbar.addEventListener('pointermove',e=>{
  if(!_indDrag)return;
  const dx=e.clientX-_indDrag.sx;
  if(Math.abs(dx)>7)_indDrag.moved=true;
  const max=tabbar.clientWidth-6-tabInd.offsetWidth;
  tabInd.style.left=Math.max(6,Math.min(max,_indDrag.base+dx))+'px';
  const center=tabInd.offsetLeft+tabInd.offsetWidth/2;
  let near=0,best=1e9;
  const items=[...tabbar.querySelectorAll('.tab-item')];
  items.forEach((t,i)=>{
    const c=t.offsetLeft+t.offsetWidth/2,d=Math.abs(c-center);
    if(d<best){best=d;near=i}
  });
  items.forEach((t,i)=>t.classList.toggle('active',i===near));
});
function _indEnd(){
  if(!_indDrag)return;
  const moved=_indDrag.moved,downTarget=_indDrag.target;
  _indDrag=null;
  tabbar.classList.remove('dragging','ind-pressed');
  /* 拖动时以松手位置的 tab 为准；未拖动（点击）时用按下的 tab */
  const a=moved?tabbar.querySelector('.tab-item.active'):(downTarget||tabbar.querySelector('.tab-item.active'));
  if(a){layoutInd();switchTab(a.dataset.tab)}
}
tabbar.addEventListener('pointerup',_indEnd);
tabbar.addEventListener('pointercancel',_indEnd);

/* ============================================================
   二级页 / 应用列表
   ============================================================ */
let subKind=null;
let _subNoAnim=false;
function openSub(kind){
  subKind=kind;
  const isDiag=kind==='diag';
  $('sub-applist').style.display=isDiag?'none':'';
  const subDiag=$('sub-diag');
  if(subDiag)subDiag.style.display=isDiag?'':'none';
  const titleMap={third:'第三方应用',system:'系统应用',white:'白名单',phoenix:'不死鸟',picker:'选择应用',frozen:'已冻结',protected:'守护中',diag:'诊断工具'};
  $('subTitle').textContent=titleMap[kind];
  const act=$('subAction');
  if(kind==='third'){act.textContent='全选';act.style.color='';act.style.display=''}
  else if(kind==='system'){act.textContent='清空';act.style.color='var(--red)';act.style.display=''}
  else if(kind==='white'||kind==='phoenix'){act.textContent='添加';act.style.color='';act.style.display=''}
  else{act.style.display='none'}
  $('appSearchInput').value='';store.query='';syncSearch();
  if(isDiag){
    runDiag();
  }else{
    renderAppList();
  }
  $('subLayer').classList.add('active');
  if(_subNoAnim)$('subLayer').style.animation='none';
  document.body.classList.add('no-scroll');
}
function closeSub(){
  $('subLayer').classList.remove('active');
  document.body.classList.remove('no-scroll');
}
document.querySelectorAll('[data-sub]').forEach(b=>b.addEventListener('click',()=>openSub(b.dataset.sub)));
/* 首页统计卡：点击进入对应二级页（已冻结 / 守护中 / 不死鸟） */
document.querySelectorAll('[data-stat]').forEach(b=>b.addEventListener('click',()=>{
  const map={frozen:'frozen',protected:'protected',phoenix:'phoenix'};
  openSub(map[b.dataset.stat]);
}));
document.querySelectorAll('[data-back]').forEach(b=>b.addEventListener('click',()=>{
  if(subKind==='picker')openSub(store.pickerBack||'white');else closeSub();
}));
/* ============ 长按已冻结应用 → 快捷操作 ============ */
let _lpTimer=null,_lp=null,_sheetKey=null;
function clearLongPress(){if(_lpTimer){clearTimeout(_lpTimer);_lpTimer=null}_lp=null}
function showAppSheet(key){
  const app=store.apps.find(a=>a.key===key);
  if(!app)return;
  _sheetKey=key;
  $('sheetTitle').innerHTML='<b>'+esc(appDisplayName(app))+'</b>'+esc(app.pkg);
  $('sheetMask').classList.add('show');
  $('actionSheet').classList.add('show');
}
function hideAppSheet(){
  $('sheetMask').classList.remove('show');
  $('actionSheet').classList.remove('show');
}
$('sheetCancel').addEventListener('click',hideAppSheet);
$('sheetMask').addEventListener('click',hideAppSheet);
/* 解冻：移出冻结（演示立即生效；真机=移出冻结名单，模块不再自动冻结） */
$('sheetUnfreeze').addEventListener('click',()=>{
  const key=_sheetKey;if(!key)return;
  delete store.third[key];delete store.system[key];
  if(!IS_KSU)store.frozenKeys=store.frozenKeys.filter(k=>k!==key);
  if(IS_KSU)saveConfig();
  hideAppSheet();
  renderAppList();renderCounts();renderHome();
  toast(IS_KSU?'已移出冻结名单，模块将不再冻结该应用':'已解冻');
});
/* 加入白名单：永不冻结 */
$('sheetWhite').addEventListener('click',()=>{
  const key=_sheetKey;if(!key)return;
  store.white[key]=true;delete store.third[key];delete store.system[key];
  if(!IS_KSU)store.frozenKeys=store.frozenKeys.filter(k=>k!==key);
  if(IS_KSU)saveConfig();
  hideAppSheet();
  renderAppList();renderCounts();renderHome();
  toast('已加入白名单，模块将不再冻结');
});
$('sheetPhoenix').addEventListener('click',()=>{
  const key=_sheetKey;if(!key)return;
  store.phoenix[key]=true;delete store.white[key];
  if(IS_KSU)saveConfig();
  hideAppSheet();
  renderAppList();renderCounts();renderHome();
  toast('已设为不死鸟');
});
$('sheetCopy').addEventListener('click',()=>{
  const app=store.apps.find(a=>a.key===_sheetKey);
  if(!app)return;
  const pkg=app.pkg;
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(pkg).then(()=>toast('已复制包名')).catch(()=>toast(pkg));
  }else toast(pkg);
  hideAppSheet();
});
/* 长按触发：仅"已冻结"列表生效（触摸 450ms / 鼠标按住） */
const lpWrap=$('appListWrap');
lpWrap.addEventListener('touchstart',e=>{
  if(subKind!=='frozen')return;
  const cell=e.target.closest('.app-cell');if(!cell)return;
  _lp={key:cell.dataset.key,y:e.touches[0].clientY};
  _lpTimer=setTimeout(()=>{_lpTimer=null;showAppSheet(_lp.key)},450);
},{passive:true});
lpWrap.addEventListener('touchmove',e=>{if(_lp&&Math.abs(e.touches[0].clientY-_lp.y)>10)clearLongPress()},{passive:true});
lpWrap.addEventListener('touchend',clearLongPress,{passive:true});
lpWrap.addEventListener('touchcancel',clearLongPress,{passive:true});
lpWrap.addEventListener('mousedown',e=>{
  if(subKind!=='frozen')return;
  const cell=e.target.closest('.app-cell');if(!cell)return;
  _lp={key:cell.dataset.key,y:e.clientY};
  _lpTimer=setTimeout(()=>{_lpTimer=null;showAppSheet(_lp.key)},450);
});
lpWrap.addEventListener('mousemove',e=>{if(_lp&&Math.abs(e.clientY-_lp.y)>10)clearLongPress()});
lpWrap.addEventListener('mouseup',clearLongPress);

/* ============================================================
   诊断工具
   ============================================================ */
const DIAG_NAMES={
  mask:'面具环境',android:'系统版本',selinux:'SELinux',boot:'启动状态',
  service_sh:'启动脚本',bin_tombstone:'守护二进制','bin_apptype.dex':'系统识别库','bin_pmlabel.dex':'应用名称库',
  webroot:'WebUI 界面',module_prop:'模块配置',lock:'锁文件',
  process:'守护进程',binary_exec:'二进制执行',log:'日志文件',frozen:'冻结状态',
  cgroup_path:'cgroup 结构',cgroup_write:'cgroup 可写',system_freezer:'系统冻结器',health:'健康状态'
};
const DIAG_GROUPS={ENV:'环境',FILE:'文件',RUN:'运行',CAP:'系统能力'};
const MOD_DIR='/data/adb/modules/TombstoneWatchdog';
/* 修复动作：按 TYPE/name/status 匹配；cmd 为可配置项 */
const DIAG_FIXES=[
  {test:(t,n,s)=>t==='FILE'&&(n==='service_sh'||n==='bin_tombstone')&&s==='fail',
   label:'修复文件权限',confirm:'将修复相关文件权限，是否继续？',
   cmd:'chmod 755 '+MOD_DIR+'/service.sh '+MOD_DIR+'/bin/tombstone_watchdog 2>/dev/null; chmod 755 '+MOD_DIR+'/bin/* 2>/dev/null'},
  {test:(t,n,s)=>(t==='RUN'&&n==='process'||n==='lock')&&s==='fail',
   label:'重启守护进程',confirm:'将重启守护进程，冻结状态会短暂中断，是否继续？',
   cmd:'kill -9 $(cat '+MOD_DIR+'/.watchdog.lock 2>/dev/null) 2>/dev/null; sleep 1; sh '+MOD_DIR+'/service.sh start'},
  {test:(t,n,s)=>n==='system_freezer'&&s==='warn',
   label:'关闭系统冻结器',confirm:'关闭后需重启手机生效，是否继续？',
   cmd:'settings put global cached_apps_freezer disabled'},
  {test:(t,n,s)=>n==='frozen'&&s==='warn',
   label:'重置状态目录',confirm:'将清空 .state，已冻结记录丢失，是否继续？',destructive:true,
   cmd:'rm -rf '+MOD_DIR+'/.state/*'},
  {test:(t,n,s)=>n==='binary_exec'&&s==='fail',
   nofix:true,hint:'可能是二进制不兼容，请联系开发者'}
];
/* 演示模式诊断输出（展示各状态与修复项） */
const DEMO_DIAG=[
  'SUMMARY|health|warn|守护进程运行中 · 发现 3 项需要处理',
  'ENV|mask|ok|Magisk Delta v26.4',
  'ENV|android|ok|Android 15 (API 35)',
  'ENV|selinux|ok|Enforcing',
  'ENV|boot|ok|正常启动',
  'FILE|service_sh|ok|service.sh 权限 755',
  'FILE|bin_tombstone|ok|tombstone_watchdog 存在',
  'FILE|bin_apptype.dex|ok|系统识别库正常',
  'FILE|bin_pmlabel.dex|ok|应用名称库正常',
  'FILE|webroot|ok|webroot 完整',
  'FILE|module_prop|ok|module.prop 正常',
  'FILE|lock|fail|锁文件缺失或不可读',
  'RUN|process|ok|PID 3182 运行中',
  'RUN|binary_exec|ok|二进制执行正常',
  'RUN|log|ok|日志可写',
  'RUN|frozen|warn|state 目录存在残留标记',
  'CAP|cgroup_path|ok|cgroup 路径正确',
  'CAP|cgroup_write|ok|cgroup 可写',
  'CAP|system_freezer|warn|系统冻结器已开启'
].join('\n');
let _diag=[];
function statusSvg(status){
  if(status==='ok')return '<svg viewBox="0 0 24 24"><path d="M9.5 16.2 5.3 12l-1.4 1.4 5.6 5.6L20.1 8l-1.4-1.4-9.2 9.6z"/></svg>';
  if(status==='warn')return '<svg viewBox="0 0 24 24"><path d="M12 2 1 21h22L12 2zm1 14h-2v-2h2v2zm0-4h-2V8h2v4z"/></svg>';
  return '<svg viewBox="0 0 24 24"><path d="M6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12 19 6.4 17.6 5 12 10.6 6.4 5z"/></svg>';
}
/* 骨架屏：进页面先渲染完整结构（各分组占位扫光），数据异步回填 */
function renderDiagSkeleton(){
  const l=(w,sm)=>'<span class="skel-line'+(sm?' sm':'')+'" style="width:'+w+'%"></span>';
  $('diagSummary').innerHTML='<span class="diag-dot xl skel-dot"></span><div class="diag-sum-txt">'+l(38)+l(72)+'</div>';
  let h='';
  ['环境','文件','运行','系统能力'].forEach((g,gi)=>{
    h+='<div class="group"><div class="group-head">'+g+'</div><div class="card">';
    const rows=gi===1?7:5;
    for(let i=0;i<rows;i++){
      h+='<div class="cell diag-row"><span class="diag-dot skel-dot"></span><span class="cell-main">'+
        l(Math.min(88,50+(i*9)%34))+l(Math.min(72,34+(i*13)%34),true)+'</span></div>';
    }
    h+='</div></div>';
  });
  $('diagGroups').innerHTML=h;
  h='<div class="group"><div class="group-head">修复建议</div><div class="card">';
  for(let i=0;i<2;i++){
    h+='<div class="cell diag-row"><span class="diag-dot skel-dot"></span><span class="cell-main">'+
      l(46)+l(60,true)+'</span><span class="diag-fix-btn" style="background:rgba(120,120,128,.14);width:76px;height:30px"></span></div>';
  }
  h+='</div></div>';
  $('diagFixes').innerHTML=h;
  $('diagFail').style.display='none';
}
async function runDiag(){
  const groupsEl=$('diagGroups'),sumEl=$('diagSummary'),fixEl=$('diagFixes'),failEl=$('diagFail');
  if(!groupsEl)return;
  renderDiagSkeleton();
  let text='';
  if(IS_KSU){
    const r=await exec('sh '+MOD_DIR+'/bin/diag.sh | base64 -w 0 2>/dev/null');
    if(r.errno===0&&(r.stdout||'').trim()){
      try{text=decodeURIComponent(escape(atob(r.stdout.trim())))}catch(e){}
    }
  }else{
    text=DEMO_DIAG;
  }
  if(!text){
    failEl.style.display='flex';groupsEl.innerHTML='';return;
  }
  _diag=text.split('\n').map(l=>l.trim()).filter(l=>l&&l.includes('|')).map(l=>{
    const p=l.split('|');
    return{type:p[0]||'',name:p[1]||'',status:p[2]||'',detail:p.slice(3).join('|')||''};
  });
  renderDiag();
  const bad=_diag.filter(i=>i.type!=='SUMMARY'&&i.status!=='ok').length;
  toast(bad?('体检完成，发现 '+bad+' 项需处理'):'体检完成，全部正常');
}
function renderDiag(){
  const items=_diag;
  /* SUMMARY 大号置顶 */
  const summary=items.find(i=>i.type==='SUMMARY')||items.find(i=>i.name==='health');
  const sumEl=$('diagSummary');
  if(summary){
    sumEl.innerHTML='<span class="diag-dot xl '+summary.status+'">'+statusSvg(summary.status)+'</span>'+
      '<div class="diag-sum-txt"><b>'+esc(DIAG_NAMES[summary.name]||summary.name)+'</b><span>'+esc(summary.detail)+'</span></div>';
  }else sumEl.innerHTML='';
  /* 分组列表 */
  let html='';
  ['ENV','FILE','RUN','CAP'].forEach(g=>{
    const rows=items.filter(i=>i.type===g);
    if(!rows.length)return;
    html+='<div class="group"><div class="group-head">'+DIAG_GROUPS[g]+'</div><div class="card">';
    rows.forEach(i=>{
      html+='<div class="cell diag-row"><span class="diag-dot '+i.status+'">'+statusSvg(i.status)+'</span>'+
        '<span class="cell-main"><span class="cell-title">'+esc(DIAG_NAMES[i.name]||i.name)+'</span>'+
        (i.detail?'<span class="cell-sub">'+esc(i.detail)+'</span>':'')+'</span></div>';
    });
    html+='</div></div>';
  });
  $('diagGroups').innerHTML=html;
  /* 修复建议（仅实际出问题项，SUMMARY 已在顶部总览） */
  const bad=items.filter(i=>i.type!=='SUMMARY'&&i.status!=='ok');
  let f='';
  if(bad.length){
    f='<div class="group"><div class="group-head">修复建议</div><div class="card">';
    bad.forEach(i=>{
      const fix=DIAG_FIXES.find(r=>r.test(i.type,i.name,i.status));
      f+='<div class="cell diag-row"><span class="diag-dot '+i.status+'">'+statusSvg(i.status)+'</span>'+
        '<span class="cell-main"><span class="cell-title">'+esc(DIAG_NAMES[i.name]||i.name)+'</span>'+
        '<span class="cell-sub">'+esc(fix&&fix.nofix?fix.hint:i.detail)+'</span></span>'+
        (fix&&!fix.nofix?'<button class="diag-fix-btn" data-fix="'+esc(i.name)+'">'+fix.label+'</button>':'')+'</div>';
    });
    f+='</div></div>';
  }else{
    f='<div class="group"><div class="group-head">修复建议</div><div class="card"><div class="diag-ok-hint">'+
      '<svg viewBox="0 0 24 24"><path d="M9.5 16.2 5.3 12l-1.4 1.4 5.6 5.6L20.1 8l-1.4-1.4-9.2 9.6z"/></svg>'+
      '未发现问题，一切正常</div></div></div>';
  }
  $('diagFixes').innerHTML=f;
}
let _diagFix=null;
function confirmDiagFix(fix){
  _diagFix=fix;
  $('diagModalText').textContent=fix.confirm;
  const ok=$('diagModalOk');
  ok.textContent=fix.destructive?'确认重置':'立即修复';
  ok.className='alert-btn bold'+(fix.destructive?' destructive':'');
  $('diagModal').classList.add('show');
}
$('diagModalOk').addEventListener('click',async()=>{
  const fix=_diagFix;if(!fix)return;
  $('diagModal').classList.remove('show');
  toast('正在修复…');
  if(IS_KSU){
    const r=await exec(fix.cmd);
    if(r.errno!==0){toast('操作失败，请检查 Root 权限');return}
  }
  toast('修复完成');
  runDiag();
});
$('diagModalCancel').addEventListener('click',()=>$('diagModal').classList.remove('show'));
$('diagModal').addEventListener('click',e=>{if(e.target===$('diagModal'))$('diagModal').classList.remove('show')});
$('diagFixes').addEventListener('click',e=>{
  const b=e.target.closest('[data-fix]');if(!b)return;
  const item=_diag.find(i=>i.name===b.dataset.fix);
  const fix=item&&DIAG_FIXES.find(r=>r.test(item.type,item.name,item.status));
  if(fix)confirmDiagFix(fix);
});
$('diagRerun').addEventListener('click',runDiag);
$('diagExport').addEventListener('click',exportDiag);
$('diagRetry').addEventListener('click',runDiag);
$('subAction').addEventListener('click',()=>{
  if(subKind==='third'){
    const list=listFor('third')||[];
    const all=list.length>0&&list.every(a=>store.third[a.key]);
    list.forEach(a=>{if(all)delete store.third[a.key];else store.third[a.key]=true});
    toast(all?'已取消全选':'已全选 '+list.length+' 个应用');
  }else if(subKind==='system'){
    const list=listFor('system')||[];
    const all=list.length>0&&list.every(a=>store.system[a.key]);
    list.forEach(a=>{if(all)delete store.system[a.key];else store.system[a.key]=true});
    toast(all?'已取消全选':'已全选 '+list.length+' 个应用');
  }else if(subKind==='white'||subKind==='phoenix'){
    store.pickerBack=subKind;openSub('picker');
    return;
  }
  if(IS_KSU)saveConfig();
  renderAppList();renderCounts();renderHome();
});
function matches(a,q){return !q||a.name.toLowerCase().includes(q)||a.pkg.toLowerCase().includes(q)}
function listFor(kind){
  if(!store.apps.length)return null;
  if(kind==='third')return store.apps.filter(a=>!a.isSystem&&!store.white[a.key]&&!store.phoenix[a.key]);
  if(kind==='system')return store.apps.filter(a=>a.isSystem&&!store.white[a.key]);
  if(kind==='white')return store.apps.filter(a=>store.white[a.key]);
  if(kind==='phoenix')return store.apps.filter(a=>store.phoenix[a.key]);
  if(kind==='frozen')return store.frozenKeys.map(key=>store.apps.find(a=>a.key===key)).filter(Boolean);
  if(kind==='protected')return store.apps.filter(a=>store.third[a.key]||store.system[a.key]||store.phoenix[a.key]);
  if(kind==='picker')return store.apps.slice();
  return null;
}
function renderAppList(){
  const wrap=$('appListWrap'),sum=$('appSummary');if(!wrap)return;
  const q=store.query;
  let list=listFor(subKind);
  if(!list)return;
  list=list.filter(a=>matches(a,q));
  const isPicker=subKind==='picker';
  const readonly=subKind==='frozen'||subKind==='protected';
  if(!isPicker&&!readonly&&subKind!=='third'&&subKind!=='system'){
    list=list.filter(a=>store[subKind][a.key]);
  }
  if(!list.length){
    wrap.innerHTML='<div class="empty"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><div class="t">'+(q?'没有匹配的应用':(subKind==='frozen'?'暂无冻结应用':subKind==='protected'?'暂无守护应用':'暂无应用'))+'</div><div class="s">'+(q?'换个关键词试试':(subKind==='frozen'?'应用被冻结后会出现在这里':'点击右上角添加'))+'</div></div>';
    sum.textContent='';return;
  }
  let html='<div class="card" style="overflow:hidden">';
  list.forEach(a=>{
    if(isPicker){
      const sel=store[store.pickerBack][a.key];
      html+='<button class="cell app-cell'+(sel?' checked':'')+'" data-add="'+esc(a.key)+'">'+appIconFor(a.pkg)+
        '<span class="cell-main"><span class="app-name">'+esc(appDisplayName(a))+'</span><span class="app-pkg">'+esc(a.pkg)+'</span></span>'+
        '<span class="check-dot"><svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg></span></button>';
    }else if(readonly){
      const tag=subKind==='protected'
        ?(store.phoenix[a.key]?'<span class="app-tag phx">不死鸟</span>':a.isSystem?'<span class="app-tag sys">系统</span>':'<span class="app-tag third">第三方</span>')
        :(a.userId!==0?'<span class="app-tag sys">分身</span>':'');
      html+='<div class="cell app-cell" data-key="'+esc(a.key)+'">'+appIconFor(a.pkg)+
        '<span class="cell-main"><span class="app-name">'+esc(appDisplayName(a))+'</span><span class="app-pkg">'+esc(a.pkg)+'</span></span>'+
        tag+'</div>';
    }else{
      const checked=store[subKind][a.key];
      const rmMode=subKind==='white'||subKind==='phoenix';
      html+='<div class="cell app-cell'+(rmMode?'':' has-switch')+'" data-key="'+esc(a.key)+'">'+appIconFor(a.pkg)+
        '<span class="cell-main"><span class="app-name">'+esc(appDisplayName(a))+'</span><span class="app-pkg">'+esc(a.pkg)+'</span></span>'+
        (rmMode
          ?'<button class="nav-action danger" data-rm="'+esc(a.key)+'">移除</button>'
          :'<label class="switch"><input type="checkbox" data-tg="'+esc(a.key)+'"'+(checked?' checked':'')+'><span class="track"></span><span class="thumb"></span></label>')+'</div>';
    }
  });
  html+='</div>';
  wrap.innerHTML=html;
  revealWhenReady(wrap);
  wrap.querySelectorAll('[data-tg]').forEach(cb=>cb.addEventListener('change',e=>{
    const key=e.target.dataset.tg,on=e.target.checked;
    store[subKind][key]=on;
    if(!on&&!IS_KSU)store.frozenKeys=store.frozenKeys.filter(k=>k!==key);
    if(IS_KSU)saveConfig();
    renderCounts();renderHome();
    toast(on?'已加入冻结名单':'已移出冻结名单');
  }));
  wrap.querySelectorAll('[data-rm]').forEach(b=>b.addEventListener('click',()=>{
    delete store[subKind][b.dataset.rm];
    if(IS_KSU)saveConfig();
    renderAppList();renderCounts();
    toast('已移除');
  }));
  wrap.querySelectorAll('[data-add]').forEach(b=>b.addEventListener('click',()=>{
    const key=b.dataset.add,target=store.pickerBack;
    if(store[target][key])delete store[target][key];else store[target][key]=true;
    if(IS_KSU)saveConfig();
    renderAppList();
  }));
  const total=listFor(subKind)?listFor(subKind).length:0;
  if(subKind==='third')sum.textContent='共 '+total+' 个应用 · 已选 '+Object.values(store.third).filter(Boolean).length+' 个';
  else if(subKind==='system')sum.textContent='共 '+total+' 个应用 · 已选 '+Object.values(store.system).filter(Boolean).length+' 个';
  else if(subKind==='white')sum.textContent='共 '+Object.values(store.white).filter(Boolean).length+' 个应用';
  else if(subKind==='phoenix')sum.textContent='共 '+Object.values(store.phoenix).filter(Boolean).length+' 个应用';
  else if(subKind==='frozen')sum.textContent='当前冻结 '+total+' 个应用';
  else if(subKind==='protected')sum.textContent='正在守护 '+total+' 个应用';
  else sum.textContent='';
}
function syncSearch(){
  const s=$('appSearch');if(!s)return;
  s.classList.toggle('has-text',!!store.query);
  $('appSearchInput').value=store.query;
}
$('appSearchInput').addEventListener('input',e=>{store.query=e.target.value.toLowerCase();syncSearch();renderAppList()});
$('appSearchClear').addEventListener('click',()=>{store.query='';syncSearch();renderAppList();$('appSearchInput').focus()});

/* ============================================================
   计数 / 模式 / 日志
   ============================================================ */
function renderCounts(){
  $('cntThird').textContent=Object.values(store.third).filter(Boolean).length;
  $('cntSystem').textContent=Object.values(store.system).filter(Boolean).length;
  $('cntWhite').textContent=Object.values(store.white).filter(Boolean).length;
  $('cntPhoenix').textContent=Object.values(store.phoenix).filter(Boolean).length;
  const mode=store.mode;
  document.querySelectorAll('#modeSeg button').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));
  positionSeg($('modeSeg'),$('modeThumb'));
  $('modeHint').textContent=mode==='manual'?'只冻结你勾选的应用，白名单仍然生效。':'冻结所有第三方应用（系统应用除外），白名单例外。';
}
function positionSeg(seg,thumb){
  if(!seg||!thumb)return;
  const btn=seg.querySelector('button.active');
  if(!btn)return;
  thumb.style.left=btn.offsetLeft+'px';
  thumb.style.width=btn.offsetWidth+'px';
}
$('modeSeg').querySelectorAll('button').forEach(b=>b.addEventListener('click',async()=>{
  const nm=b.dataset.mode;if(nm===store.mode)return;
  const ok=await confirmBox(nm==='global'?'切换到全部冻结':'切换到手动选择',
    nm==='global'?['所有第三方应用（含分身）将被冻结。','请把输入法、音乐等加入白名单。']:['只冻结名单内的应用，白名单仍然生效。'],
    '确认切换','取消');
  if(!ok)return;
  store.mode=nm;
  if(IS_KSU)saveConfig();
  renderCounts();toast('已切换为'+(nm==='global'?'全部冻结':'手动选择'));
}));
$('logSeg').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
  store.logMode=b.dataset.lmode;
  b.parentElement.querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));
  positionSeg($('logSeg'),$('logThumb'));
  renderLogs();
}));
if($('chartRange')){
  $('chartRange').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
    store.chartRange=b.dataset.range;
    store.chartOffset=0;
    b.parentElement.querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));
    positionSeg($('chartRange'),$('chartRangeThumb'));
    renderChart();
  }));
}
if($('cwPrev'))$('cwPrev').addEventListener('click',()=>shiftChart(1));
if($('cwNext'))$('cwNext').addEventListener('click',()=>shiftChart(-1));
window.addEventListener('resize',()=>{positionSeg($('modeSeg'),$('modeThumb'));positionSeg($('chartRange'),$('chartRangeThumb'));renderChart();layoutInd()});

/* 演示日志（无 KSU 时） */
function demoLogs(){
  if(store.logItems.length||IS_KSU)return;
  const mk=(h,m,type,n,p,detail,day)=>({type,name:n,pkg:p,detail,time:(()=>{const d=new Date();d.setHours(h,m,0,0);return d})(),day});
  const ev=[
    mk(7,45,'fail','饿了么','me.ele','权限不足','today'),
    mk(8,12,'skip','微博','com.sina.weibo','显示悬浮窗','today'),
    mk(8,56,'unfreeze','QQ','com.tencent.mobileqq','前台使用','today'),
    mk(9,28,'freeze','美团','com.sankuai.meituan','后台超时','today'),
    mk(9,30,'gone','小红书','com.xingin.xhs','','today'),
    mk(9,35,'freeze','哔哩哔哩','tv.danmaku.bili','后台超时','today'),
    mk(9,38,'skip','快手','com.smile.gifmaker','正在播放音频','today'),
    mk(9,40,'phoenix','网易云音乐','com.netease.cloudmusic','不死鸟保护','today'),
    mk(9,41,'freeze','抖音','com.ss.android.ugc.aweme','后台超时','today'),
    mk(9,42,'unfreeze','微信','com.tencent.mm','前台使用','today'),
  ];
  const yev=[
    mk(21,45,'freeze','京东','com.jingdong.app.mall','后台超时','yest'),
    mk(21,50,'skip','微博','com.sina.weibo','正在播放音频','yest'),
    mk(21,58,'gone','闲鱼','com.taobao.idlefish','','yest'),
    mk(22,5,'phoenix','QQ音乐','com.tencent.qqmusic','不死鸟保护','yest'),
    mk(22,10,'freeze','知乎','com.zhihu.android','后台超时','yest'),
    mk(22,14,'freeze','淘宝','com.taobao.taobao','后台超时','yest'),
    mk(22,15,'unfreeze','拼多多','com.xunmeng.pinduoduo','前台使用','yest'),
  ];
  store.logItems=[...ev,...yev];
}
function renderTimeline(){
  const wrap=$('timelineWrap');if(!wrap)return;
  const items=store.logItems.filter(i=>i.day==='today');
  if(!items.length){wrap.innerHTML='';return}
  const byApp={};
  items.forEach(it=>{if(!byApp[it.pkg])byApp[it.pkg]=[];byApp[it.pkg].push(it)});
  const apps=Object.keys(byApp).sort((a,b)=>byApp[b].length-byApp[a].length).slice(0,8);
  const now=new Date(),nowMin=now.getHours()*60+now.getMinutes();
  let html='<div class="card timeline-card"><div class="timeline-head"><span>今日冻结时间线</span><span class="timeline-legend"><i style="background:#0A84FF"></i>冻结<i style="background:#BF5AF2"></i>不死鸟</span></div>';
  html+='<div class="timeline-body">';
  apps.forEach(pkg=>{
    const evs=byApp[pkg].sort((a,b)=>a.time-b.time);
    const name=appNameOf(pkg)||pkg;
    const segs=[];let freezeStart=null,freezeType='freeze';
    evs.forEach(ev=>{
      if(ev.type==='freeze'||ev.type==='phoenix'){if(!freezeStart){freezeStart=ev.time;freezeType=ev.type}}
      else if(ev.type==='unfreeze'||ev.type==='gone'){
        if(freezeStart){
          const s=freezeStart.getHours()*60+freezeStart.getMinutes();
          const e=ev.time.getHours()*60+ev.time.getMinutes();
          if(e>s)segs.push({s,e,type:freezeType});
          freezeStart=null;
        }
      }
    });
    if(freezeStart){
      const s=freezeStart.getHours()*60+freezeStart.getMinutes();
      const e=nowMin>s?nowMin:1440;
      if(e>s)segs.push({s,e,type:freezeType});
    }
    const segsHTML=segs.map(seg=>{
      const left=(seg.s/1440*100).toFixed(2);
      const width=Math.max(0.4,(seg.e-seg.s)/1440*100).toFixed(2);
      const color=seg.type==='phoenix'?'#BF5AF2':'#0A84FF';
      return '<span class="tl-seg" style="left:'+left+'%;width:'+width+'%;background:'+color+'"></span>';
    }).join('');
    html+='<div class="tl-row"><span class="tl-name" title="'+esc(pkg)+'">'+esc(name)+'</span><span class="tl-track">'+segsHTML+'</span></div>';
  });
  html+='</div><div class="tl-axis"><span>00</span><span>06</span><span>12</span><span>18</span><span>24</span></div></div>';
  wrap.innerHTML=html;
}
function renderLogs(){
  const list=$('logList'),raw=$('logRawView'),tl=$('timelineWrap');
  if(!list||!raw)return;
  if(store.logMode==='raw'){
    list.style.display='none';raw.style.display='block';if(tl)tl.style.display='none';
    const text=store.logRaw||(IS_KSU?'':'（演示版无原始日志，接入真机后显示 watchdog.log）');
    raw.innerHTML='<div class="card"><div class="log-raw">'+esc(text||'暂无日志')+'</div></div>';
    return;
  }
  list.style.display='';raw.style.display='none';if(tl)tl.style.display='';
  renderTimeline();
  const items=store.logItems;
  const today=items.filter(i=>i.day==='today').reverse(),yest=items.filter(i=>i.day==='yest').reverse();
  list.innerHTML=
    '<div class="log-group-title">今天</div><div class="card" style="overflow:hidden">'+(today.length?today.map(logCardHTML).join(''):'<div class="empty" style="padding:22px 16px"><div class="t">暂无事件</div></div>')+'</div>'+
    '<div class="log-group-title">昨天</div><div class="card" style="overflow:hidden">'+(yest.length?yest.map(logCardHTML).join(''):'<div class="empty" style="padding:22px 16px"><div class="t">暂无事件</div></div>')+'</div>';
  revealWhenReady(list);
}
$('btnClearLog').addEventListener('click',async()=>{
  const ok=await confirmBox('清空日志',['确认清空所有运行日志？','此操作不可撤销。'],'清空','取消');
  if(!ok)return;
  if(IS_KSU){
    const r=await exec(`> ${LOG_PATH}`);
    toast(r.errno===0?'日志已清空':'清空失败');
    store.logRaw='';store.logItems=[];renderLogs();
  }else{
    store.logItems=[];store.logRaw='';renderLogs();toast('日志已清空（演示）');
  }
});

/* ============================================================
   设置
   ============================================================ */
function initSettings(){
  document.querySelectorAll('.stepper').forEach(sp=>{
    const key=sp.dataset.key,min=+sp.dataset.min,max=+sp.dataset.max,
          step=sp.dataset.step?+sp.dataset.step:1,unit=sp.dataset.unit||'';
    const invert=sp.dataset.invert==='1';
    const val=store.settings[key];
    sp.innerHTML='<button data-d="-1">−</button><span class="val">'+val+(unit?' '+unit:'')+'</span><button data-d="1">+</button>';
    const set=v=>{
      store.settings[key]=v;
      if(IS_KSU)saveConfig();
      initSettings();renderCounts();
    };
    /* 数值越小优先级越高（OOM 优先级）："+"=提高优先级=数值减小，"−"=降低优先级=数值增大 */
    const stepDown=()=>invert?Math.min(max,val+step):Math.max(min,val-step);
    const stepUp=()=>invert?Math.max(min,val-step):Math.min(max,val+step);
    sp.querySelector('[data-d="-1"]').addEventListener('click',()=>set(stepDown()));
    sp.querySelector('[data-d="1"]').addEventListener('click',()=>set(stepUp()));
  });
  document.querySelectorAll('.switch input[data-key]').forEach(cb=>{
    cb.checked=!!store.settings[cb.dataset.key];
    cb.addEventListener('change',()=>{
      store.settings[cb.dataset.key]=cb.checked?1:0;
      if(IS_KSU)saveConfig();
      toast('已保存');
    });
  });
}
/* 背景（演示：本地即时应用；真机：从模块目录读写） */
function applyBg(dataUrl){
  document.querySelectorAll('.bg-layer,.bg-overlay').forEach(e=>e.remove());
  const st=$('bgStatus'),cr=$('bgClearRow');
  if(dataUrl){
    const l=document.createElement('div');l.className='bg-layer';
    l.style.backgroundImage='url('+dataUrl+')';
    const o=document.createElement('div');o.className='bg-overlay';
    document.body.insertBefore(o,document.body.firstChild);
    document.body.insertBefore(l,document.body.firstChild);
    document.body.classList.add('has-bg');
    if(st)st.textContent='已设置';
    if(cr)cr.style.display='';
  }else{
    document.body.classList.remove('has-bg');
    if(st)st.textContent='未设置';
    if(cr)cr.style.display='none';
  }
}
function processImageFile(file){
  return new Promise((resolve,reject)=>{
    if(!file){reject(new Error('未选择文件'));return}
    if(file.size>20*1024*1024){reject(new Error('图片不能超过 20MB'));return}
    const reader=new FileReader();
    reader.onload=e=>{
      const img=new Image();
      img.onload=()=>{
        try{
          let w=img.naturalWidth||img.width,h=img.naturalHeight||img.height;
          if(w===0||h===0)throw new Error('图片尺寸无效');
          const max=1920;
          if(w>max||h>max){const r=Math.min(max/w,max/h);w=Math.max(1,Math.round(w*r));h=Math.max(1,Math.round(h*r))}
          const c=document.createElement('canvas');c.width=w;c.height=h;
          const x=c.getContext('2d');x.fillStyle='#FFFFFF';x.fillRect(0,0,w,h);x.drawImage(img,0,0,w,h);
          const dataUrl=c.toDataURL('image/jpeg',0.85);
          if(!dataUrl||dataUrl.length<100)throw new Error('导出失败');
          resolve(dataUrl);
        }catch(err){reject(new Error('图片处理失败: '+err.message))}
      };
      img.onerror=()=>reject(new Error('图片格式不支持或已损坏'));
      img.src=e.target.result;
    };
    reader.onerror=()=>reject(new Error('文件读取失败'));
    reader.readAsDataURL(file);
  });
}
$('bgUpload').addEventListener('change',async e=>{
  const f=e.target.files&&e.target.files[0];if(!f)return;
  toast('处理中…');
  try{
    const dataUrl=await processImageFile(f);
    applyBg(dataUrl);
    if(IS_KSU){
      await saveBgToFile(dataUrl);
      toast('背景已设置');
    }else{
      toast('背景已设置（演示）');
    }
  }catch(err){toast('失败: '+err.message)}
  e.target.value='';
});
$('bgClearRow').addEventListener('click',()=>{
  if(IS_KSU)clearBgReal();else{applyBg(null);toast('背景已清除')}
});

/* ============================================================
   弹窗
   ============================================================ */
function confirmBox(title,msg,okText,cancelText){
  return new Promise(res=>{
    const m=$('confirmModal');
    $('confirmTitle').textContent=title;
    $('confirmMsg').innerHTML=Array.isArray(msg)?msg.map(x=>'<div>'+esc(x)+'</div>').join(''):esc(msg);
    $('confirmOk').textContent=okText||'确定';
    $('confirmCancel').textContent=cancelText||'取消';
    m.classList.add('show');
    const done=r=>{m.classList.remove('show');$('confirmOk').onclick=null;$('confirmCancel').onclick=null;const mk=m.querySelector('.mask');if(mk)mk.onclick=null;res(r)};
    $('confirmOk').onclick=()=>done(true);
    $('confirmCancel').onclick=()=>done(false);
    const mk=m.querySelector('.mask');if(mk)mk.onclick=()=>done(false);
  });
}
function promptBox(title,msg,def){
  return new Promise(res=>{
    const m=$('promptModal');
    $('promptTitle').textContent=title;
    $('promptMsg').textContent=msg;
    $('promptInput').value=def||'';
    m.classList.add('show');
    setTimeout(()=>{const i=$('promptInput');if(i)i.focus()},80);
    const done=r=>{m.classList.remove('show');$('promptOk').onclick=null;$('promptCancel').onclick=null;const mk=m.querySelector('.mask');if(mk)mk.onclick=null;res(r)};
    $('promptOk').onclick=()=>done($('promptInput').value);
    $('promptCancel').onclick=()=>done(null);
    const mk=m.querySelector('.mask');if(mk)mk.onclick=()=>done(null);
  });
}
$('aboutRow').addEventListener('click',()=>confirmBox('守护墓碑 v4.0.1',['守护机制：C++ 原生守护','数据目录：/data/adb/modules/TombstoneWatchdog',IS_KSU?'当前为真机模式 · 数据实时读写':'当前为演示模式 · 未检测到 KernelSU 桥'],'知道了'));
$('safeExit').addEventListener('click',()=>{
  if(IS_KSU){exitSafeMode();return}
  confirmBox('退出安全模式',['退出后守护进程将在下次开机时启动。','模式将切换为「手动选择」。'],'确认退出','取消').then(ok=>{
    if(ok){$('safeBanner').classList.remove('show');document.body.classList.remove('has-safe');toast('已退出，请重启手机')}
  });
});

/* ============================================================
   首次引导
   ============================================================ */
let obStep=1;
function initOnboard(){
  if(IS_KSU)return; /* 真机用户跳过引导 */
  if(localStorage.getItem('tw_ob_done')||location.search.includes('nob'))return;
  const ob=$('onboard');if(!ob)return;
  ob.classList.add('show');
  renderObStep();
}
function renderObStep(){
  const ob=$('onboard');if(!ob)return;
  const steps=[
    {icon:'<svg viewBox="0 0 24 24"><path d="M12 3 4 9v12h5v-7h6v7h5V9l-8-6z"/></svg>',
     grad:'linear-gradient(135deg,#5AC8FA,#007AFF)',
     title:'守护墓碑',desc:'让后台应用安静地冻结<br>保留状态 · 极低耗电',btn:'开始',next:2},
    {icon:'<svg viewBox="0 0 24 24"><path d="M4 5h16v2H4zm0 6h16v2H4zm0 6h10v2H4z"/></svg>',
     grad:'linear-gradient(135deg,#0A84FF,#4DA3FF)',
     title:'选择运行模式',desc:'稍后可在「应用」页更改',btn:'下一步',next:3},
    {icon:'<svg viewBox="0 0 24 24"><path d="M12 2 1 21h22L12 2zm1 14h-2v-2h2v2zm0-4h-2V8h2v4z"/></svg>',
     grad:'linear-gradient(135deg,#FF9500,#FFB340)',
     title:'冻结微信需谨慎',desc:'微信未接入系统推送通道<br>冻结后无法接收实时消息',btn:'开始使用',next:0},
  ];
  const s=steps[obStep-1];
  ob.innerHTML='<div class="ob-card">'+
    '<div class="ob-icon" style="background:'+s.grad+'">'+s.icon+'</div>'+
    '<div class="ob-title">'+s.title+'</div>'+
    '<div class="ob-desc">'+s.desc+'</div>'+
    '<button class="ob-btn" id="obGo">'+s.btn+'</button>'+
    '<div class="ob-step">'+steps.map((x,i)=>'<i class="'+(i===obStep-1?'on':'')+'"></i>').join('')+'</div>'+
  '</div>';
  $('obGo').addEventListener('click',()=>{
    if(s.next===0){
      ob.classList.remove('show');localStorage.setItem('tw_ob_done','1');
      toast('设置已保存');
    }else{obStep=s.next;renderObStep()}
  });
}

/* ============================================================
   初始化
   ============================================================ */
async function init(){
  const p=new URLSearchParams(location.search);
  const initTab=p.get('tab');
  if(initTab&&TABS.includes(initTab))switchTab(initTab);
  const initSub=p.get('sub');
  if(initSub&&['third','system','white','phoenix','picker'].includes(initSub)){_subNoAnim=true;openSub(initSub)}

  if(IS_KSU){
    /* ---- 真机模式 ---- */
    try{
      const cfg=await readConfig();
      if(cfg){
        store.mode=cfg.mode;
        store.third=cfg.apps||{};
        store.system=cfg.systemApps||{};
        store.white=cfg.whitelist||{};
        store.phoenix=cfg.phoenix||{};
        Object.assign(store.settings,cfg.settings);
      }
      renderCounts();initSettings();renderHome();
      await Promise.all([loadCustomBg(),checkStatus(),loadStats(),loadLogs()]);
      await loadPackages();
      renderAppList();renderCounts();renderLogs();renderRecent();
      checkSafeMode();
      checkFreezerConflict();
      hideBoot('已连接守护进程');
      setInterval(checkStatus,5000);
      setInterval(loadStats,60000);
      setInterval(checkSafeMode,30000);
    }catch(e){
      console.error('init 异常:',e);
      const t=$('heroTitle');
      if(t)t.textContent='初始化失败: '+e.message;
      hideBoot('初始化失败');
    }
  }else{
    /* ---- 演示模式 ---- */
    demoLogs();
    renderHome();renderCounts();initSettings();renderLogs();initOnboard();
    if(p.get('safe')==='1'){$('safeBanner').classList.add('show');document.body.classList.add('has-safe')}
    hideBoot('已就绪');
  }
  positionSeg($('logSeg'),$('logThumb'));
  positionSeg($('chartRange'),$('chartRangeThumb'));
  layoutInd();
}
document.addEventListener('DOMContentLoaded',()=>init());
